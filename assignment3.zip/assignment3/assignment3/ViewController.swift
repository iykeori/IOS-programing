//
//  ViewController.swift
//  assignment3
//
//  Created by w0427115 on 2020-02-19.
//  Copyright © 2020 w0427115. All rights reserved.
//

import UIKit

class ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

